# coding=utf-8
"""Replay evaluation for QMAP page-migration policies.

The evaluator replays a page trace against a small DRAM/NVM model and reports
the prototype metrics used by the paper experiments:

  - hit rate
  - NVM reads/writes
  - migration count
  - weighted access cost
  - policy decision/inference overhead

Supported policies are LRU, Random, LFU, CLOCK, QMAP, and lightweight learned
baselines. The QMAP path loads a checkpoint produced by qmap_train.py and uses
the same lightweight feature construction as qmap_generator.py.
"""

import argparse
import hashlib
import json
import math
import os
import random
import shlex
import sys
import time

try:
  from qmap_generator import build_candidate_state_features
  from qmap_generator import apply_history_ablation
  from qmap_generator import get_lru_tail_candidates_and_mask
  from qmap_generator import padded_history
  from qmap_generator import read_trace
except ImportError:
  from qmap.qmap_generator import build_candidate_state_features
  from qmap.qmap_generator import apply_history_ablation
  from qmap.qmap_generator import get_lru_tail_candidates_and_mask
  from qmap.qmap_generator import padded_history
  from qmap.qmap_generator import read_trace


PROJECT_ROOT = os.path.dirname(os.path.abspath(os.path.dirname(__file__)))
if PROJECT_ROOT not in sys.path:
  sys.path.insert(0, PROJECT_ROOT)

from qmap import candidate_filter
from qmap import finals_config
from qmap import no_vpn_ablation


DRAM_READ_COST = 1.0
DRAM_WRITE_COST = 1.0
NVM_READ_COST = 2.0
NVM_WRITE_COST = 8.0
MIGRATION_COST = 10.0
ABLATION_CHOICES = (
    "full", "cross_attention", "no_pc", "no_rw", "mean_pool",
    "no_qformer", "no_cost")


def build_arg_parser():
  parser = argparse.ArgumentParser(description="Evaluate QMAP by trace replay.")
  parser.add_argument("--trace_path", default=None,
                      help="Input CSV trace with PC,Address and optional RW.")
  parser.add_argument("--config", default=None,
                      help="Resolved, versioned CAPD finals config.")
  parser.add_argument(
      "--evaluation_split", choices=("test", "valid"), default="test",
      help=(
          "Resolved-config split to replay. Defaults to test for historical "
          "runs; post-Stage-6 selection must explicitly use valid."))
  parser.add_argument("--selector_params", default=None,
                      help="Frozen selector_params.json for QMAP finals_v2.")
  parser.add_argument("--checkpoint", default=None,
                      help="QMAP checkpoint path. Required for --policy qmap.")
  parser.add_argument("--learned_model", default=None,
                      help=("JSON model path for kleio_lite or "
                            "patterns_lite policies."))
  parser.add_argument("--policy",
                      choices=("lru", "random", "lfu", "clock", "qmap",
                               "kleio_lite", "patterns_lite"),
                      required=True)
  parser.add_argument("--dram_capacity", type=int, default=128)
  parser.add_argument("--page_shift", type=int, default=0)
  parser.add_argument("--history_length", type=int, default=10)
  parser.add_argument("--candidate_count", type=int, default=64)
  parser.add_argument("--rank_guard", type=int, default=0,
                      help=("For QMAP, restrict inference to the first N "
                            "LRU-tail candidates. 0 disables the guard."))
  parser.add_argument("--rank_score_penalty", type=float, default=0.0,
                      help=("For QMAP, subtract penalty * normalized_rank "
                            "from candidate scores. Rank 0 is the oldest "
                            "LRU-tail page; 0 disables the penalty."))
  parser.add_argument("--lookahead", type=int, default=256,
                      help=("Scale used for DRAM residency features. Match "
                            "the generator lookahead used for training."))
  parser.add_argument("--random_seed", type=int, default=0)
  parser.add_argument(
      "--stage5_replay_seed", type=int, default=None,
      help=("Explicit Random replay seed for the preregistered stage-5 "
            "multi-seed baseline. Invalid for every other policy."))
  parser.add_argument("--device", default=None,
                      help="cpu, cuda, or omitted for auto selection.")
  parser.add_argument("--dram_read_cost", type=float, default=DRAM_READ_COST)
  parser.add_argument("--dram_write_cost", type=float, default=DRAM_WRITE_COST)
  parser.add_argument("--nvm_read_cost", type=float, default=NVM_READ_COST)
  parser.add_argument("--nvm_write_cost", type=float, default=NVM_WRITE_COST,
                      help=("Weighted access cost for a write served from "
                            "NVM. Default is 8 for write-pressure testing."))
  parser.add_argument("--migration_cost", type=float, default=MIGRATION_COST)
  parser.add_argument("--json_output", default=None,
                      help="Optional path to write machine-readable metrics.")
  parser.add_argument(
      "--stage6_profile", action="store_true",
      help=("Collect synchronized per-decision/component latency samples and "
            "runtime memory evidence for CAPD stage 6."))
  parser.add_argument(
      "--stage6_warmup_decisions", type=int, default=20,
      help=("Number of initial policy decisions excluded from stage-6 "
            "latency percentiles."))
  parser.add_argument(
      "--bridge_diagnostics", action="store_true",
      help=(
          "Record post-hoc QMAP-vs-LRU victim disagreement, bounded next-use "
          "outcomes, score margins, and victim-sequence identity. This is "
          "diagnostic evidence only and must not be used for test tuning."))
  parser.add_argument("--ablation", choices=ABLATION_CHOICES, default=None,
                      help=("QMAP ablation variant. Defaults to the checkpoint "
                            "model_args value for --policy qmap."))
  return parser


def _quantile(values, probability):
  """Returns a deterministic linearly interpolated quantile."""
  if not values:
    return 0.0
  ordered = sorted(float(value) for value in values)
  if len(ordered) == 1:
    return ordered[0]
  position = (len(ordered) - 1) * float(probability)
  lower = int(math.floor(position))
  upper = int(math.ceil(position))
  if lower == upper:
    return ordered[lower]
  fraction = position - lower
  return ordered[lower] * (1.0 - fraction) + ordered[upper] * fraction


def _sample_summary(values):
  values = [float(value) for value in values]
  if not values:
    return {
        "count": 0, "mean": 0.0, "min": 0.0, "p50": 0.0,
        "p95": 0.0, "p99": 0.0, "max": 0.0}
  return {
      "count": len(values),
      "mean": sum(values) / float(len(values)),
      "min": min(values),
      "p50": _quantile(values, 0.50),
      "p95": _quantile(values, 0.95),
      "p99": _quantile(values, 0.99),
      "max": max(values),
  }


def _process_peak_rss_bytes():
  """Best-effort peak resident-set size, normalized to bytes."""
  try:
    import resource
    value = int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    # Linux reports KiB while macOS reports bytes.
    return value if sys.platform == "darwin" else value * 1024
  except (ImportError, AttributeError, ValueError):
    return None


class ReplayStats(object):
  """Tracks replay metrics."""

  def __init__(self, stage6_profile=False, warmup_decisions=20,
               bridge_diagnostics=False):
    if warmup_decisions < 0:
      raise ValueError("warmup_decisions must be non-negative.")
    self.total_accesses = 0
    self.hit_count = 0
    self.miss_count = 0
    self.migration_count = 0
    self.nvm_read_count = 0
    self.nvm_write_count = 0
    self.weighted_access_cost = 0.0
    self.decision_count = 0
    self.decision_time_seconds = 0.0
    self.selector_decision_count = 0
    self.selector_time_seconds = 0.0
    self.selector_B_t = []
    self.selector_K_t = []
    self.stage6_profile = bool(stage6_profile)
    self.profile_warmup_decisions = int(warmup_decisions)
    self.profile_decision_samples_ms = []
    self.profile_component_samples_ms = {}
    self.profile_selector_samples_ms = []
    self.profile_memory = {}
    self.replay_wall_seconds = 0.0
    self.bridge_diagnostics = bool(bridge_diagnostics)
    self.bridge_lru_victim_disagreements = 0
    self.bridge_lru_in_retained_candidates = 0
    self.bridge_better_next_use = 0
    self.bridge_worse_next_use = 0
    self.bridge_equal_next_use = 0
    self.bridge_distance_advantages = []
    self.bridge_score_margins = []
    self.bridge_victim_sequence = hashlib.sha256()

  @property
  def hit_rate(self):
    if self.total_accesses == 0:
      return 0.0
    return self.hit_count / float(self.total_accesses)

  @property
  def avg_decision_time_ms(self):
    if self.decision_count == 0:
      return 0.0
    return self.decision_time_seconds * 1000.0 / float(self.decision_count)

  @property
  def avg_selector_time_ms(self):
    if self.selector_decision_count == 0:
      return 0.0
    return (self.selector_time_seconds * 1000.0 /
            float(self.selector_decision_count))

  def record_selector(self, snapshot):
    self.selector_decision_count += 1
    self.selector_time_seconds += snapshot["selector_time_seconds"]
    self.selector_B_t.append(snapshot["B_t"])
    self.selector_K_t.append(snapshot["K_t"])
    if (self.stage6_profile and
        self.decision_count >= self.profile_warmup_decisions):
      self.profile_selector_samples_ms.append(
          float(snapshot["selector_time_seconds"]) * 1000.0)

  def record_decision(self, elapsed_seconds, component_timings=None):
    """Records one decision while preserving historical aggregate fields."""
    elapsed_seconds = float(elapsed_seconds)
    if elapsed_seconds < 0.0 or not math.isfinite(elapsed_seconds):
      raise ValueError("Decision latency must be finite and non-negative.")
    include_profile = (
        self.stage6_profile and
        self.decision_count >= self.profile_warmup_decisions)
    self.decision_time_seconds += elapsed_seconds
    self.decision_count += 1
    if not include_profile:
      return
    self.profile_decision_samples_ms.append(elapsed_seconds * 1000.0)
    for name, value in (component_timings or {}).items():
      value = float(value)
      if value < 0.0 or not math.isfinite(value):
        raise ValueError("Component latency must be finite and non-negative.")
      self.profile_component_samples_ms.setdefault(name, []).append(
          value * 1000.0)

  def record_bridge_decision(
      self, access_index, victim, lru_victim, qmap_next_use,
      lru_next_use, score_margin, retained_candidates):
    """Records one diagnostic comparison without affecting replay behavior."""
    if not self.bridge_diagnostics:
      return
    self.bridge_victim_sequence.update(
        "{}:{}\n".format(int(access_index), int(victim)).encode("ascii"))
    if lru_victim in retained_candidates:
      self.bridge_lru_in_retained_candidates += 1
    if victim != lru_victim:
      self.bridge_lru_victim_disagreements += 1
      advantage = int(qmap_next_use) - int(lru_next_use)
      self.bridge_distance_advantages.append(advantage)
      if advantage > 0:
        self.bridge_better_next_use += 1
      elif advantage < 0:
        self.bridge_worse_next_use += 1
      else:
        self.bridge_equal_next_use += 1
    if score_margin is not None:
      score_margin = float(score_margin)
      if not math.isfinite(score_margin) or score_margin < 0.0:
        raise ValueError("Bridge score margin must be finite and non-negative.")
      self.bridge_score_margins.append(score_margin)

  @property
  def throughput_accesses_per_second(self):
    if self.replay_wall_seconds <= 0.0:
      return 0.0
    return self.total_accesses / float(self.replay_wall_seconds)

  def to_dict(self, policy, trace_path, dram_capacity):
    result = {
        "policy": policy,
        "trace_path": trace_path,
        "dram_capacity": dram_capacity,
        "total_accesses": self.total_accesses,
        "hits": self.hit_count,
        "misses": self.miss_count,
        "hit_rate": self.hit_rate,
        "hit_rate_percent": self.hit_rate * 100.0,
        "migrations": self.migration_count,
        "nvm_reads": self.nvm_read_count,
        "nvm_writes": self.nvm_write_count,
        "weighted_access_cost": self.weighted_access_cost,
        "decision_count": self.decision_count,
        "decision_time_seconds": self.decision_time_seconds,
        "avg_decision_time_ms": self.avg_decision_time_ms,
        "replay_wall_seconds": self.replay_wall_seconds,
        "throughput_accesses_per_second":
            self.throughput_accesses_per_second,
        "candidate_filter": {
            "decision_count": self.selector_decision_count,
            "min_B_t": min(self.selector_B_t) if self.selector_B_t else 0,
            "max_B_t": max(self.selector_B_t) if self.selector_B_t else 0,
            "mean_B_t": (sum(self.selector_B_t) /
                         float(len(self.selector_B_t))
                         if self.selector_B_t else 0.0),
            "min_K_t": min(self.selector_K_t) if self.selector_K_t else 0,
            "max_K_t": max(self.selector_K_t) if self.selector_K_t else 0,
            "mean_K_t": (sum(self.selector_K_t) /
                         float(len(self.selector_K_t))
                         if self.selector_K_t else 0.0),
            "selector_time_seconds": self.selector_time_seconds,
            "avg_selector_time_ms": self.avg_selector_time_ms,
        },
    }
    if self.stage6_profile:
      components = dict(self.profile_component_samples_ms)
      if self.profile_selector_samples_ms:
        components["selector"] = list(self.profile_selector_samples_ms)
      components["full_decision"] = list(
          self.profile_decision_samples_ms)
      result["stage6_profile"] = {
          "schema_version": "capd_finals_v3_stage6_profile_1",
          "clock": "time.perf_counter",
          "cuda_synchronization": "component_boundaries_for_qmap",
          "warmup_decisions": self.profile_warmup_decisions,
          "measured_decisions": len(self.profile_decision_samples_ms),
          "latency_ms": {
              name: _sample_summary(values)
              for name, values in sorted(components.items())
          },
          "samples_ms": {
              name: list(values)
              for name, values in sorted(components.items())
          },
          "memory": dict(self.profile_memory),
      }
    if self.bridge_diagnostics:
      decisions = int(self.decision_count)
      disagreements = int(self.bridge_lru_victim_disagreements)
      result["bridge_diagnostics"] = {
          "schema_version": "capd_bridge_decision_diagnostics_1",
          "scientific_role": "post_hoc_diagnostic_not_selection",
          "test_used_for_selection": False,
          "decision_count": decisions,
          "victim_sequence_fingerprint":
              self.bridge_victim_sequence.hexdigest(),
          "lru_victim_disagreements": disagreements,
          "lru_victim_disagreement_rate": (
              disagreements / float(decisions) if decisions else 0.0),
          "lru_in_retained_candidates":
              int(self.bridge_lru_in_retained_candidates),
          "lru_in_retained_candidates_rate": (
              self.bridge_lru_in_retained_candidates / float(decisions)
              if decisions else 0.0),
          "disagreement_next_use_outcomes": {
              "qmap_better": int(self.bridge_better_next_use),
              "qmap_worse": int(self.bridge_worse_next_use),
              "equal": int(self.bridge_equal_next_use),
          },
          "bounded_next_use_distance_advantage":
              _sample_summary(self.bridge_distance_advantages),
          "top1_top2_score_margin":
              _sample_summary(self.bridge_score_margins),
      }
    return result


def dram_access_cost(rw, args):
  return args.dram_write_cost if rw else args.dram_read_cost


def nvm_access_cost(rw, args):
  return args.nvm_write_cost if rw else args.nvm_read_cost


def rank_score_penalty_values(candidate_count, penalty):
  """Returns per-rank score penalties for LRU-tail candidates."""
  if candidate_count <= 0:
    raise ValueError("candidate_count must be positive.")
  if penalty < 0.0:
    raise ValueError("rank_score_penalty must be non-negative.")
  if candidate_count == 1 or penalty == 0.0:
    return [0.0 for _ in range(candidate_count)]
  normalizer = float(candidate_count - 1)
  return [penalty * rank / normalizer for rank in range(candidate_count)]


def _flat_sequence(values, name):
  """Converts a one-dimensional list/tensor-like value to a Python list."""
  if hasattr(values, "detach"):
    values = values.detach()
  if hasattr(values, "cpu"):
    values = values.cpu()
  if hasattr(values, "tolist"):
    values = values.tolist()
  else:
    try:
      values = list(values)
    except TypeError as error:
      raise ValueError("{} must be a one-dimensional sequence.".format(
          name)) from error
  if not isinstance(values, list) or any(
      isinstance(value, (list, tuple)) for value in values):
    raise ValueError("{} must be a one-dimensional sequence.".format(name))
  return values


def select_v3_reranker_victim(candidate_pages, reranker_scores,
                               candidate_mask, original_pool_ranks):
  """Selects the deterministic CAPD v3 victim from a frozen snapshot.

  Highest final reranker score wins. Exact score ties are broken only by the
  smallest pre-decision original_pool_rank (the oldest LRU page). Selector
  scores and candidate tensor positions are deliberately absent.
  """
  pages = _flat_sequence(candidate_pages, "candidate_pages")
  scores = _flat_sequence(reranker_scores, "reranker_scores")
  mask = _flat_sequence(candidate_mask, "candidate_mask")
  ranks = _flat_sequence(original_pool_ranks, "original_pool_ranks")
  size = len(pages)
  if size == 0:
    raise ValueError("Victim selection requires at least one candidate.")
  if not (len(scores) == size and len(mask) == size and len(ranks) == size):
    raise ValueError(
        "candidate_pages, reranker_scores, candidate_mask and "
        "original_pool_ranks must have identical shapes.")

  valid = []
  seen_ranks = set()
  for index, (score, mask_value, rank) in enumerate(
      zip(scores, mask, ranks)):
    if mask_value not in (0, 1):
      raise ValueError("candidate_mask values must be exactly 0 or 1.")
    if mask_value == 0:
      continue
    try:
      score = float(score)
    except (TypeError, ValueError) as error:
      raise ValueError("Valid reranker scores must be numeric.") from error
    if not math.isfinite(score):
      raise ValueError("Valid reranker scores must be finite.")
    if isinstance(rank, bool):
      raise ValueError("Valid original_pool_ranks must be integers.")
    try:
      integer_rank = int(rank)
    except (TypeError, ValueError, OverflowError) as error:
      raise ValueError(
          "Valid original_pool_ranks must be non-negative integers.") from error
    if integer_rank != rank or integer_rank < 0:
      raise ValueError(
          "Valid original_pool_ranks must be non-negative integers.")
    if integer_rank in seen_ranks:
      raise ValueError("Valid original_pool_ranks must be unique.")
    seen_ranks.add(integer_rank)
    valid.append((index, score, integer_rank))

  if not valid:
    raise ValueError("candidate_mask must contain at least one valid candidate.")
  maximum_score = max(item[1] for item in valid)
  tied = [item for item in valid if item[1] == maximum_score]
  victim_index = min(tied, key=lambda item: item[2])[0]
  return pages[victim_index]


def uses_qformer(ablation):
  return ablation == "full"


def checkpoint_uses_qformer(model_args, extractor_state):
  """Keeps old Q-Former checkpoints loadable while new runs default to Pool."""
  ablation = model_args.get("ablation", "mean_pool")
  if uses_qformer(ablation):
    return True
  return any(key.startswith("_qformer.") for key in extractor_state)


def infer_scorer_scoring_input(model_args, scorer_state):
  """Infers whether a checkpoint scores cat(u, g) or the context vector g."""
  hidden_dim = model_args.get("hidden_dim", 18)
  first_weight = scorer_state.get("_scoring_mlp.0.weight")
  if first_weight is not None and len(first_weight.shape) == 2:
    input_dim = first_weight.shape[1]
    if input_dim == hidden_dim:
      return "context"
    if input_dim == hidden_dim * 2:
      return "concat"
  return model_args.get("scoring_input", "context")


def infer_extractor_pooling_strategy(model_args, scoring_input):
  if model_args.get("pooling_strategy"):
    return model_args["pooling_strategy"]
  return "none" if scoring_input == "context" else "mean"


def update_mru(dram_pages, page):
  """Moves an existing DRAM page to MRU position."""
  dram_pages.remove(page)
  dram_pages.insert(0, page)


def choose_victim_lru(dram_pages):
  return dram_pages[-1]


def choose_victim_random(dram_pages, rng):
  return rng.choice(dram_pages)


def choose_victim_lfu(dram_pages, access_frequency, last_access_time):
  return min(
      dram_pages,
      key=lambda page: (access_frequency.get(page, 0),
                        last_access_time.get(page, -1)))


def bounded_next_use_distance(trace, access_index, page, lookahead):
  """Returns next-use distance capped at lookahead+1 for diagnostics."""
  limit = min(len(trace), int(access_index) + int(lookahead) + 1)
  for future_index in range(int(access_index) + 1, limit):
    if trace[future_index]["page"] == page:
      return future_index - int(access_index)
  return int(lookahead) + 1


def is_learned_policy(policy):
  return policy in ("kleio_lite", "patterns_lite")


def validate_checkpoint_config_contract(
    checkpoint, config, selector_params, selector_config=None):
  """Rejects every frozen Generator/Trainer/Replay contract mismatch."""
  selector_config = selector_config or config
  if checkpoint.get("schema_version") != config["schema_version"]:
    raise ValueError("Checkpoint/config schema mismatch.")
  finals_config.validate_artifact_identity(config, checkpoint, "checkpoint")
  finals_config.validate_selector_params(selector_config, selector_params)
  expected_contract = finals_config.contract_from_config(config)
  finals_config.assert_contract_matches(
      expected_contract, checkpoint.get("experiment_contract", {}),
      "checkpoint")
  expected_config_fingerprint = finals_config.config_fingerprint(config)
  if checkpoint.get("config_fingerprint") != expected_config_fingerprint:
    raise ValueError("Checkpoint/config fingerprint mismatch.")
  expected_selector_fingerprint = finals_config.selector_fingerprint(
      selector_params)
  if checkpoint.get("selector_fingerprint") != expected_selector_fingerprint:
    raise ValueError("Checkpoint/selector fingerprint mismatch.")
  if config["schema_version"] == finals_config.SCHEMA_VERSION:
    embedded_selector = checkpoint.get("selector_params")
    if embedded_selector is None:
      raise ValueError("Checkpoint is missing embedded selector_params.")
    finals_config.validate_selector_params(selector_config, embedded_selector)
    if finals_config.selector_fingerprint(
        embedded_selector) != expected_selector_fingerprint:
      raise ValueError("Checkpoint embedded selector mismatch.")
  expected_holdout_fingerprint = selector_params.get(
      "decision_holdout_fingerprint")
  is_v3 = config["schema_version"] == finals_config.SCHEMA_VERSION
  uses_independent_validation = (
      is_v3 and finals_config.uses_independent_validation(config))
  if is_v3:
    required_checkpoint = (
        "feature_embedder", "extractor", "scorer", "model_args", "seed",
        "best_epoch", "best_validation_loss", "selector_params",
        "jsonl_fingerprints", "vocab_contract")
    missing_checkpoint = [
        key for key in required_checkpoint if key not in checkpoint]
    if missing_checkpoint:
      raise ValueError("Checkpoint missing fields: {}".format(
          missing_checkpoint))
    vocab_contract = checkpoint.get("vocab_contract", {})
    required_vocab = (
        "page_frozen", "pc_frozen", "unk_index",
        "page_vocab_fingerprint", "pc_vocab_fingerprint")
    if any(key not in vocab_contract for key in required_vocab):
      raise ValueError("Checkpoint is missing the v3 vocabulary contract.")
    if (vocab_contract["page_frozen"] is not True or
        vocab_contract["pc_frozen"] is not True or
        int(vocab_contract["unk_index"]) != 0):
      raise ValueError("Checkpoint vocabularies must be frozen with UNK=0.")
    model_args = checkpoint.get("model_args", {})
    if model_args.get("shared_page_embedding") is not True:
      raise ValueError("Checkpoint does not use the shared page embedding.")
    expected_page_id_embedding = finals_config.use_page_id_embedding(config)
    if bool(model_args.get("use_page_id_embedding", True)) != (
        expected_page_id_embedding):
      raise ValueError("Checkpoint page-ID embedding mode mismatch.")
    expected_position = config["model"]["position_encoding"]
    if model_args.get("position_encoding") != expected_position:
      raise ValueError("Checkpoint position encoding mismatch.")
    expected_context_mode = (
        "history_mean_pool"
        if config.get("stage5_variant", {}).get("variant_id") ==
        "history_mean_pool" else "cross_attention")
    if model_args.get("context_mode", "cross_attention") != (
        expected_context_mode):
      raise ValueError("Checkpoint stage-5 context mode mismatch.")
    seed_source = checkpoint.get("training_seed_source", "config_default")
    if seed_source not in ("config_default", "explicit_cli"):
      raise ValueError("Checkpoint training_seed_source is invalid.")
    if (seed_source == "config_default" and
        int(checkpoint["seed"]) != int(config["training"]["seed"])):
      raise ValueError("Checkpoint default training seed mismatch.")
    if int(checkpoint["best_epoch"]) <= 0:
      raise ValueError("Checkpoint best_epoch must be positive.")
    jsonl_fingerprints = checkpoint.get("jsonl_fingerprints", {})
    if set(jsonl_fingerprints) != {"train", "valid"}:
      raise ValueError("Checkpoint must bind train and valid JSONL.")
  if uses_independent_validation:
    if (selector_params.get("decision_holdout") is not None or
        expected_holdout_fingerprint is not None or
        checkpoint.get("decision_holdout") is not None or
        checkpoint.get("decision_holdout_fingerprint") is not None):
      raise ValueError("Official v3 rejects decision-holdout artifacts.")
  else:
    selector_holdout = selector_params.get("decision_holdout", {})
    finals_config.validate_decision_holdout(selector_holdout, config)
    if expected_holdout_fingerprint != selector_holdout["fingerprint"]:
      raise ValueError("Selector decision holdout fingerprint mismatch.")
    if checkpoint.get(
        "decision_holdout_fingerprint") != expected_holdout_fingerprint:
      raise ValueError("Checkpoint/decision holdout fingerprint mismatch.")
  model_args = checkpoint.get("model_args", {})
  if int(model_args.get("page_state_dim", -1)) != expected_contract[
      "page_state_dim"]:
    raise ValueError("Checkpoint model page_state_dim mismatch.")
  return expected_contract


def apply_replay_finals_config(args):
  """Makes the resolved config authoritative for every replay policy."""
  config_path = getattr(args, "config", None)
  if not config_path:
    if not getattr(args, "trace_path", None):
      raise ValueError("--trace_path is required when --config is omitted.")
    return None
  config = finals_config.load_config(
      config_path, require_resolved=True, project_root=PROJECT_ROOT,
      verify_manifest_files=(
          getattr(args, "evaluation_split", "test") == "test"))
  evaluation_split = getattr(args, "evaluation_split", "test")
  configured_trace = config["data"][
      "{}_trace".format(evaluation_split)]
  supplied_trace = getattr(args, "trace_path", None)
  if (supplied_trace and
      os.path.abspath(supplied_trace) != os.path.abspath(configured_trace)):
    raise ValueError(
        "--trace_path does not match resolved config {}_trace.".format(
            evaluation_split))
  args.trace_path = configured_trace
  args.dram_capacity = int(config["memory"]["dram_capacity_pages"])
  args.history_length = int(config["history"]["transformer_H"])
  args.lookahead = int(config["features"]["residency_scale_Lres"])
  args.page_shift = int(config.get("trace", {}).get("page_shift", 12))
  args.random_seed = int(config["evaluation"]["random_seed"])
  if getattr(args, "stage5_replay_seed", None) is not None:
    if args.policy != "random":
      raise ValueError("--stage5_replay_seed is valid only for Random.")
    if args.stage5_replay_seed < 0:
      raise ValueError("--stage5_replay_seed must be non-negative.")
    args.random_seed = int(args.stage5_replay_seed)
  for name, value in config["cost_model"].items():
    setattr(args, name, float(value))
  if getattr(args, "rank_guard", 0) != 0:
    raise ValueError("rank_guard is not part of the frozen finals_v2 path.")
  if getattr(args, "rank_score_penalty", 0.0) != 0.0:
    raise ValueError(
        "rank_score_penalty is not part of the frozen finals_v2 path.")
  if args.policy == "qmap":
    if not getattr(args, "selector_params", None):
      raise ValueError("--selector_params is required for finals QMAP replay.")
    args.candidate_count = int(config["candidate"]["retained_K"])
    args._data_config = (
        no_vpn_ablation.load_data_config(
            args.selector_params, PROJECT_ROOT, config)
        if "experiment_name" in config else config)
  return config


def build_replay_decision_snapshot(
    dram_pages, decision_history, access_index, dram_insert_time, dirty_pages,
    selector_history, config, selector_params):
  """Explicit adapter used by replay and Generator/Replay equivalence tests."""
  return candidate_filter.build_filtered_candidate_snapshot(
      dram_pages, decision_history, access_index, dram_insert_time,
      dirty_pages, selector_history, config, selector_params)


class ClockPolicy(object):
  """Small CLOCK policy over the current DRAM pages."""

  def __init__(self):
    self._reference_bits = {}
    self._hand = 0

  def touch(self, page):
    self._reference_bits[page] = 1

  def remove(self, page):
    self._reference_bits.pop(page, None)

  def choose_victim(self, dram_pages):
    if not dram_pages:
      raise ValueError("CLOCK cannot choose from an empty DRAM.")
    if self._hand >= len(dram_pages):
      self._hand = 0
    while True:
      page = dram_pages[self._hand]
      if self._reference_bits.get(page, 0) == 0:
        victim = page
        self._hand %= len(dram_pages)
        return victim
      self._reference_bits[page] = 0
      self._hand = (self._hand + 1) % len(dram_pages)


class QMAPPolicy(object):
  """Loads QMAP and uses the shared B-to-K selector in finals_v2."""

  def __init__(self, checkpoint_path, device, history_length, candidate_count,
               lookahead=256, ablation=None, rank_guard=0,
               rank_score_penalty=0.0, config=None, selector_params=None,
               stage6_profile=False, bridge_diagnostics=False,
               data_config=None):
    if checkpoint_path is None:
      raise ValueError("--checkpoint is required when --policy=qmap.")
    if candidate_count <= 0:
      raise ValueError("candidate_count must be positive.")
    if rank_guard < 0 or rank_score_penalty < 0.0:
      raise ValueError("rank guard/penalty must be non-negative.")

    # Lazy imports keep classical-baseline replay independent of torch.
    import torch
    from policy_learning.cache_model import embed
    from policy_learning.cache_model import model

    self._torch = torch
    self._device = device
    self._config = config
    self._selector_params = selector_params
    self._history_length = history_length
    self._candidate_count = candidate_count
    self._effective_candidate_count = (
        min(candidate_count, rank_guard) if rank_guard else candidate_count)
    self._rank_score_penalty = rank_score_penalty
    self._lookahead = lookahead
    self._selector_history = None
    self.last_selector_snapshot = None
    self.last_component_timings = {}
    self.last_score_margin = None
    self._stage6_profile = bool(stage6_profile)
    self._bridge_diagnostics = bool(bridge_diagnostics)
    self._is_v3 = False

    checkpoint = torch.load(checkpoint_path, map_location=device)
    if config is not None:
      if selector_params is None:
        raise ValueError("Finals QMAP requires selector_params.")
      contract = validate_checkpoint_config_contract(
          checkpoint, config, selector_params,
          selector_config=data_config)
      self._is_v3 = config["schema_version"] == finals_config.SCHEMA_VERSION
      self._history_length = contract["H"]
      self._candidate_count = contract["K"]
      self._effective_candidate_count = contract["K"]
      self._lookahead = contract["Lres"]
      self._selector_history = candidate_filter.SelectorHistory(
          contract["Hc"])

    model_args = checkpoint.get("model_args", {})
    self._ablation = ablation or model_args.get("ablation", "mean_pool")
    extractor_state = checkpoint["extractor"]
    scorer_state = checkpoint["scorer"]
    scoring_input = infer_scorer_scoring_input(model_args, scorer_state)
    pooling_strategy = infer_extractor_pooling_strategy(
        model_args, scoring_input)
    self._feature_embedder = embed.QMAPAccessFeatureEmbedder(
        address_embedder=embed.DynamicVocabEmbedder(
            embed_dim=model_args.get("address_embed_dim", 8),
            max_vocab_size=model_args.get("address_vocab_size", 100000)),
        pc_embedder=embed.DynamicVocabEmbedder(
            embed_dim=model_args.get("pc_embed_dim", 8),
            max_vocab_size=model_args.get("pc_vocab_size", 50000)),
        rw_embedder=embed.RWFlagEmbedder(
            embed_dim=model_args.get("rw_embed_dim", 2)),
        use_page_id_embedding=model_args.get(
            "use_page_id_embedding", True)).to(device)
    self._extractor = model.QMAPMacroscopicPatternExtractor(
        hidden_dim=model_args.get("hidden_dim", 18),
        num_queries=model_args.get("num_queries", 4),
        num_layers=model_args.get("num_layers", 1),
        num_heads=model_args.get("num_heads", 2),
        feedforward_dim=model_args.get("feedforward_dim"),
        dropout=model_args.get("dropout", 0.0),
        use_qformer=checkpoint_uses_qformer(model_args, extractor_state),
        pooling_strategy=pooling_strategy,
        position_encoding=model_args.get("position_encoding", "none"),
        max_sequence_length=self._history_length).to(device)
    self._page_state_dim = model_args.get("page_state_dim", 3)
    self._scorer = model.QMAPCandidateScorer(
        hidden_dim=model_args.get("hidden_dim", 18),
        page_state_dim=self._page_state_dim,
        page_embed_dim=model_args.get("page_embed_dim", 8),
        page_vocab_size=model_args.get("page_vocab_size", 100000),
        num_heads=model_args.get("num_heads", 2),
        dropout=model_args.get("dropout", 0.0),
        page_dim=model_args.get("page_dim", 21),
        scoring_input=scoring_input,
        shared_page_embedding=model_args.get(
            "shared_page_embedding", False),
        context_mode=model_args.get(
            "context_mode", "cross_attention"),
        use_page_id_embedding=model_args.get(
            "use_page_id_embedding", True)).to(device)
    self._feature_embedder.load_state_dict(checkpoint["feature_embedder"])
    self._extractor.load_state_dict(extractor_state)
    self._scorer.load_state_dict(scorer_state)
    if self._is_v3:
      vocab_contract = checkpoint["vocab_contract"]
      if (not self._feature_embedder.page_embedder.frozen or
          not self._feature_embedder.pc_embedder.frozen):
        raise ValueError("Loaded v3 vocabularies are not frozen.")
      page_fingerprint = finals_config.fingerprint_value(
          self._feature_embedder.page_embedder.input_to_index)
      pc_fingerprint = finals_config.fingerprint_value(
          self._feature_embedder.pc_embedder.input_to_index)
      if (page_fingerprint != vocab_contract["page_vocab_fingerprint"] or
          pc_fingerprint != vocab_contract["pc_vocab_fingerprint"]):
        raise ValueError("Loaded vocabulary fingerprint mismatch.")
    self._feature_embedder.eval()
    self._extractor.eval()
    self._scorer.eval()

  def synchronize(self):
    if self._device.type == "cuda" and self._torch.cuda.is_available():
      self._torch.cuda.synchronize(self._device)

  def _profile_start(self):
    if not self._stage6_profile:
      return None
    self.synchronize()
    return time.perf_counter()

  def _profile_end(self, started, name, timings):
    if started is None:
      return
    self.synchronize()
    timings[name] = time.perf_counter() - started

  def reset_profile_memory(self):
    if (self._stage6_profile and self._device.type == "cuda" and
        self._torch.cuda.is_available()):
      self._torch.cuda.reset_peak_memory_stats(self._device)

  def memory_profile(self):
    """Returns static model bytes and best-effort CUDA inference peaks."""
    parameter_ids = set()
    buffer_ids = set()
    parameter_bytes = 0
    buffer_bytes = 0
    for module in (
        self._feature_embedder, self._extractor, self._scorer):
      for value in module.parameters():
        identity = id(value)
        if identity not in parameter_ids:
          parameter_ids.add(identity)
          parameter_bytes += value.numel() * value.element_size()
      for value in module.buffers():
        identity = id(value)
        if identity not in buffer_ids:
          buffer_ids.add(identity)
          buffer_bytes += value.numel() * value.element_size()
    result = {
        "model_parameter_bytes": int(parameter_bytes),
        "model_buffer_bytes": int(buffer_bytes),
        "model_static_bytes": int(parameter_bytes + buffer_bytes),
        "device": str(self._device),
        "process_peak_rss_bytes": _process_peak_rss_bytes(),
    }
    if self._device.type == "cuda" and self._torch.cuda.is_available():
      result.update({
          "cuda_device_name":
              self._torch.cuda.get_device_name(self._device),
          "torch_version": str(self._torch.__version__),
          "cuda_peak_allocated_bytes": int(
              self._torch.cuda.max_memory_allocated(self._device)),
          "cuda_peak_reserved_bytes": int(
              self._torch.cuda.max_memory_reserved(self._device)),
      })
    else:
      result.update({
          "cuda_device_name": None,
          "torch_version": str(self._torch.__version__),
          "cuda_peak_allocated_bytes": 0,
          "cuda_peak_reserved_bytes": 0,
      })
    return result

  def observe(self, page, rw, access_index):
    # Called after the decision and current-page insertion, so selector
    # features at a decision never contain the triggering miss.
    if self._selector_history is not None:
      self._selector_history.observe(page, rw, access_index)

  def score_explicit_candidates(self, candidates, history, access_index,
                                dram_insert_time, dirty_pages):
    """Scores an already constructed LRU-tail set without a B-to-K selector.

    The proactive Stage-4 path owns candidate construction and may request
    fewer than K valid pages during warmup or a multi-round recovery cycle.
    Padding is masked and never returned to the caller.
    """
    candidates = list(candidates)
    if not candidates:
      return []
    if len(candidates) > self._candidate_count:
      raise ValueError(
          "Explicit candidate count exceeds checkpoint K: {} > {}.".format(
              len(candidates), self._candidate_count))
    if len(candidates) != len(set(candidates)):
      raise ValueError("Explicit candidates contain duplicates.")
    actual_count = len(candidates)
    padding = self._candidate_count - actual_count
    padded_candidates = candidates + [0] * padding
    candidate_mask = [1] * actual_count + [0] * padding
    recent_history = list(history)[-self._history_length:]
    candidate_state_features = []
    for rank, candidate in enumerate(candidates):
      residency_duration = access_index - dram_insert_time.get(
          candidate, access_index)
      candidate_state_features.append(build_candidate_state_features(
          candidate, recent_history, residency_duration,
          candidate in dirty_pages, self._lookahead, rank=rank,
          candidate_count=self._candidate_count))
    candidate_state_features += [
        [0.0] * self._page_state_dim for _ in range(padding)]
    history_page_ids, pc, rw = apply_history_ablation(
        *padded_history(recent_history, self._history_length),
        ablation=self._ablation)
    history_mask = (
        [0] * (self._history_length - len(recent_history)) +
        [1] * len(recent_history))
    torch = self._torch
    with torch.no_grad():
      history_page_ids = torch.tensor(
          [history_page_ids], dtype=torch.long, device=self._device)
      history_mask_tensor = torch.tensor(
          [history_mask], dtype=torch.float32, device=self._device)
      pc = torch.tensor([pc], dtype=torch.long, device=self._device)
      rw = torch.tensor([rw], dtype=torch.long, device=self._device)
      candidate_pages = torch.tensor(
          [padded_candidates], dtype=torch.long, device=self._device)
      candidate_state_features = torch.tensor(
          [candidate_state_features], dtype=torch.float32,
          device=self._device)
      candidate_mask_tensor = torch.tensor(
          [candidate_mask], dtype=torch.float32, device=self._device)
      access_features = self._feature_embedder(history_page_ids, pc, rw)
      z = self._extractor(
          access_features, history_mask=history_mask_tensor)
      candidate_page_embeddings = (
          self._feature_embedder.embed_pages(candidate_pages)
          if getattr(self._scorer, "_shared_page_embedding", False) else None)
      scores = self._scorer(
          z, candidate_pages, candidate_state_features,
          candidate_mask_tensor,
          candidate_page_embeddings=candidate_page_embeddings,
          history_mask=history_mask_tensor)
    return [
        float(value) for value in _flat_sequence(
            scores[0], "explicit candidate scores")[:actual_count]]

  def choose_victim(self, dram_pages, history, max_page, access_index,
                    dram_insert_time, dirty_pages):
    del max_page
    timings = {}
    started = self._profile_start()
    snapshot = None
    if self._config is not None:
      snapshot = build_replay_decision_snapshot(
          dram_pages, history, access_index, dram_insert_time, dirty_pages,
          self._selector_history, self._config, self._selector_params)
      candidates = snapshot["candidate_pages"]
      candidate_mask = snapshot["candidate_mask"]
      candidate_state_features = snapshot["candidate_state_features"]
      if self._config.get("stage5_variant", {}).get(
          "variant_id") == "no_candidate_state":
        candidate_state_features = [
            [0.0, 0.0, 0.0, 0.0]
            for _ in candidate_state_features]
    else:
      candidates, candidate_mask = get_lru_tail_candidates_and_mask(
          dram_pages, self._effective_candidate_count)
      candidate_state_features = []
      for rank, candidate in enumerate(candidates):
        residency_duration = access_index - dram_insert_time.get(
            candidate, access_index)
        if self._page_state_dim >= 4:
          features = build_candidate_state_features(
              candidate, history, residency_duration,
              candidate in dirty_pages, self._lookahead, rank=rank,
              candidate_count=self._effective_candidate_count)
        else:
          features = build_candidate_state_features(
              candidate, history, residency_duration,
              candidate in dirty_pages, self._history_length)
        candidate_state_features.append(features)
    self._profile_end(started, "selector", timings)

    started = self._profile_start()
    history_page_ids, pc, rw = apply_history_ablation(
        *padded_history(history, self._history_length),
        ablation=self._ablation)
    history_mask = ([0] * (self._history_length - len(history)) +
                    [1] * len(history))
    torch = self._torch
    with torch.no_grad():
      history_page_ids = torch.tensor(
          [history_page_ids], dtype=torch.long, device=self._device)
      history_mask_tensor = torch.tensor(
          [history_mask], dtype=torch.float32, device=self._device)
      pc = torch.tensor([pc], dtype=torch.long, device=self._device)
      rw = torch.tensor([rw], dtype=torch.long, device=self._device)
      candidate_pages = torch.tensor(
          [candidates], dtype=torch.long, device=self._device)
      candidate_state_features = torch.tensor(
          [candidate_state_features], dtype=torch.float32,
          device=self._device)
      candidate_mask_tensor = torch.tensor(
          [candidate_mask], dtype=torch.float32, device=self._device)
      access_features = self._feature_embedder(history_page_ids, pc, rw)
      self._profile_end(started, "tensor_and_embedding", timings)
      started = self._profile_start()
      z = self._extractor(
          access_features, history_mask=history_mask_tensor)
      self._profile_end(started, "transformer_encoder", timings)
      started = self._profile_start()
      candidate_page_embeddings = (
          self._feature_embedder.embed_pages(candidate_pages)
          if getattr(self._scorer, "_shared_page_embedding", False) else None)
      eviction_scores = self._scorer(
          z, candidate_pages, candidate_state_features,
          candidate_mask_tensor,
          candidate_page_embeddings=candidate_page_embeddings,
          history_mask=history_mask_tensor)
      if self._rank_score_penalty:
        rank_penalties = torch.tensor(
            [rank_score_penalty_values(
                eviction_scores.shape[1], self._rank_score_penalty)],
            dtype=eviction_scores.dtype, device=self._device)
        eviction_scores = eviction_scores - rank_penalties
      if self._bridge_diagnostics:
        valid_scores = [
            float(score) for score, valid in zip(
                _flat_sequence(
                    eviction_scores[0], "bridge eviction_scores"),
                candidate_mask)
            if valid]
        valid_scores.sort(reverse=True)
        self.last_score_margin = (
            valid_scores[0] - valid_scores[1]
            if len(valid_scores) >= 2 else 0.0)
      self._profile_end(started, "cross_attention_scorer", timings)
      started = self._profile_start()
      if self._is_v3:
        # v3 candidates are selector-ordered, not LRU-ordered. Resolve exact
        # final-score ties only from the frozen pre-decision snapshot ranks.
        victim = select_v3_reranker_victim(
            candidates, eviction_scores[0], candidate_mask,
            snapshot["original_pool_ranks"])
      else:
        # Preserve the historical v2.1/legacy first-argmax behavior.
        victim_index = int(torch.argmax(eviction_scores, dim=1).item())
        victim = candidates[victim_index]
      self._profile_end(started, "victim_selection", timings)
    self.last_selector_snapshot = snapshot
    self.last_component_timings = timings
    return victim


def replay(args, finals_replay_config=None):
  trace, _ = read_trace(args.trace_path, args.page_shift)
  max_page = max((item["page"] for item in trace), default=1)
  stats = ReplayStats(
      stage6_profile=getattr(args, "stage6_profile", False),
      warmup_decisions=getattr(args, "stage6_warmup_decisions", 20),
      bridge_diagnostics=getattr(args, "bridge_diagnostics", False))
  dram_pages = []
  # DRAM starts empty; every trace page is conceptually backed by unbounded
  # NVM, so a page's first touch is charged as an NVM access.
  nvm_pages = set(item["page"] for item in trace)
  dram_insert_time = {}
  dirty_pages = set()
  access_frequency = {}
  last_access_time = {}
  history = []
  rng = random.Random(args.random_seed)
  clock_policy = ClockPolicy()
  learned_policy = None

  qmap_policy = None
  if args.policy == "qmap":
    import torch
    device = args.device
    if device is None:
      device = "cuda" if torch.cuda.is_available() else "cpu"
    selector_params = None
    if finals_replay_config is not None:
      data_config = getattr(args, "_data_config", finals_replay_config)
      selector_params = finals_config.load_json(args.selector_params)
      if selector_params.get("config_fingerprint") != (
          finals_config.config_fingerprint(data_config)):
        raise ValueError("Replay selector/config fingerprint mismatch.")
      if selector_params.get("workload") != finals_replay_config[
          "run"]["workload"]:
        raise ValueError("Replay selector/workload mismatch.")
      finals_config.validate_selector_params(
          data_config, selector_params)
      if (finals_replay_config["schema_version"] ==
          finals_config.SCHEMA_VERSION and
          finals_config.uses_independent_validation(
              finals_replay_config)):
        if (selector_params.get("decision_holdout") is not None or
            selector_params.get("decision_holdout_fingerprint") is not None):
          raise ValueError("Official replay rejects smoke holdout selector.")
      else:
        finals_config.validate_decision_holdout(
            selector_params.get("decision_holdout", {}), finals_replay_config)
        if selector_params.get("decision_holdout_fingerprint") != (
            selector_params["decision_holdout"]["fingerprint"]):
          raise ValueError("Replay selector decision holdout mismatch.")
    qmap_policy = QMAPPolicy(
        args.checkpoint,
        torch.device(device),
        args.history_length,
        args.candidate_count,
        args.lookahead,
        args.ablation,
        args.rank_guard,
        args.rank_score_penalty,
        config=finals_replay_config,
        selector_params=selector_params,
        stage6_profile=getattr(args, "stage6_profile", False),
        bridge_diagnostics=getattr(args, "bridge_diagnostics", False),
        data_config=getattr(args, "_data_config", finals_replay_config))
    qmap_policy.reset_profile_memory()
  elif is_learned_policy(args.policy):
    if args.learned_model is None:
      raise ValueError("--learned_model is required for {}.".format(
          args.policy))
    try:
      from learned_baselines import LearnedBaselinePolicy
      from learned_baselines import load_model
    except ImportError:
      from qmap.learned_baselines import LearnedBaselinePolicy
      from qmap.learned_baselines import load_model
    learned_model = load_model(args.learned_model)
    if finals_replay_config is not None:
      if learned_model.get("schema_version") != finals_replay_config[
          "schema_version"]:
        raise ValueError("Learned baseline/config schema mismatch.")
      if finals_replay_config["schema_version"] == finals_config.SCHEMA_VERSION:
        finals_config.validate_artifact_identity(
            finals_replay_config, learned_model, "learned baseline")
      if learned_model.get("workload") != finals_replay_config[
          "run"]["workload"]:
        raise ValueError("Learned baseline workload mismatch.")
      trained_capacity = learned_model.get("training", {}).get(
          "dram_capacity")
      expected_capacity = int(
          finals_replay_config["memory"]["dram_capacity_pages"])
      if trained_capacity is None or int(trained_capacity) != expected_capacity:
        raise ValueError(
            "Learned baseline must be retrained for DRAM capacity {}."
            .format(expected_capacity))
      if int(learned_model.get("candidate_count", -1)) != 8:
        raise ValueError(
            "Finals learned baselines must retain their native tail-8 pool.")
    learned_policy = LearnedBaselinePolicy(learned_model)

  replay_started = time.perf_counter()
  for access_index, access in enumerate(trace):
    page = access["page"]
    rw = access["rw"]
    stats.total_accesses += 1
    access_frequency[page] = access_frequency.get(page, 0) + 1
    last_access_time[page] = access_index

    if page in dram_pages:
      stats.hit_count += 1
      stats.weighted_access_cost += dram_access_cost(rw, args)
      if args.policy != "clock":
        update_mru(dram_pages, page)
      else:
        clock_policy.touch(page)
      if rw:
        dirty_pages.add(page)
    else:
      stats.miss_count += 1
      stats.weighted_access_cost += nvm_access_cost(rw, args)
      if rw:
        stats.nvm_write_count += 1
      else:
        stats.nvm_read_count += 1

      if len(dram_pages) >= args.dram_capacity:
        if args.policy == "qmap":
          qmap_policy.synchronize()
        decision_start = time.perf_counter()
        if args.policy == "lru":
          victim = choose_victim_lru(dram_pages)
        elif args.policy == "random":
          victim = choose_victim_random(dram_pages, rng)
        elif args.policy == "lfu":
          victim = choose_victim_lfu(
              dram_pages, access_frequency, last_access_time)
        elif args.policy == "clock":
          victim = clock_policy.choose_victim(dram_pages)
        elif is_learned_policy(args.policy):
          decision_history = (history + [access])[-args.history_length:]
          victim = learned_policy.choose_victim(
              dram_pages, decision_history, access_index, dram_insert_time,
              dirty_pages, access_frequency, last_access_time)
        else:
          # qmap_generator.py includes the current miss in the fixed-length
          # access history before constructing a training sample. Keep replay
          # inference aligned with that feature contract.
          decision_history = (history + [access])[-args.history_length:]
          victim = qmap_policy.choose_victim(
              dram_pages, decision_history, max_page, access_index,
              dram_insert_time, dirty_pages)
          selector_snapshot = qmap_policy.last_selector_snapshot
          if selector_snapshot is not None:
            stats.record_selector(selector_snapshot)
          if stats.bridge_diagnostics:
            lru_victim = choose_victim_lru(dram_pages)
            retained = (
                selector_snapshot["candidate_pages"]
                if selector_snapshot is not None else list(dram_pages))
            stats.record_bridge_decision(
                access_index, victim, lru_victim,
                bounded_next_use_distance(
                    trace, access_index, victim, args.lookahead),
                bounded_next_use_distance(
                    trace, access_index, lru_victim, args.lookahead),
                qmap_policy.last_score_margin, retained)
          qmap_policy.synchronize()
        elapsed_seconds = time.perf_counter() - decision_start
        component_timings = (
            qmap_policy.last_component_timings
            if qmap_policy is not None else None)
        stats.record_decision(elapsed_seconds, component_timings)

        dram_pages.remove(victim)
        clock_policy.remove(victim)
        nvm_pages.add(victim)
        dram_insert_time.pop(victim, None)
        dirty_pages.discard(victim)
        stats.migration_count += 1
        stats.weighted_access_cost += args.migration_cost

      if page in nvm_pages:
        nvm_pages.remove(page)
      dram_pages.insert(0, page)
      clock_policy.touch(page)
      dram_insert_time[page] = access_index
      if rw:
        dirty_pages.add(page)

    history.append(access)
    if len(history) > args.history_length:
      history.pop(0)
    if qmap_policy is not None:
      qmap_policy.observe(page, rw, access_index)

  stats.replay_wall_seconds = time.perf_counter() - replay_started
  if stats.stage6_profile:
    stats.profile_memory = (
        qmap_policy.memory_profile() if qmap_policy is not None else {
            "model_parameter_bytes": 0,
            "model_buffer_bytes": 0,
            "model_static_bytes": 0,
            "device": "cpu",
            "cuda_device_name": None,
            "torch_version": None,
            "process_peak_rss_bytes": _process_peak_rss_bytes(),
            "cuda_peak_allocated_bytes": 0,
            "cuda_peak_reserved_bytes": 0,
        })
  return stats


def print_stats(policy, stats):
  print("Policy:", policy)
  print("Total accesses:", stats.total_accesses)
  print("Hits:", stats.hit_count)
  print("Misses:", stats.miss_count)
  print("Hit rate: {:.2f}%".format(stats.hit_rate * 100.0))
  print("Migrations:", stats.migration_count)
  print("NVM reads:", stats.nvm_read_count)
  print("NVM writes:", stats.nvm_write_count)
  print("Weighted access cost: {:.2f}".format(stats.weighted_access_cost))
  print("Policy decisions:", stats.decision_count)
  print("Total decision time: {:.6f}s".format(stats.decision_time_seconds))
  print("Avg decision time: {:.6f} ms".format(stats.avg_decision_time_ms))
  if stats.selector_decision_count:
    print("Candidate filter decisions:", stats.selector_decision_count)
    print("Candidate B_t range: {}..{}".format(
        min(stats.selector_B_t), max(stats.selector_B_t)))
    print("Retained K_t range: {}..{}".format(
        min(stats.selector_K_t), max(stats.selector_K_t)))
    print("Avg candidate filter time: {:.6f} ms".format(
        stats.avg_selector_time_ms))


def main():
  args = build_arg_parser().parse_args()
  if args.rank_score_penalty < 0.0:
    raise ValueError("--rank_score_penalty must be non-negative.")
  if args.stage6_warmup_decisions < 0:
    raise ValueError("--stage6_warmup_decisions must be non-negative.")
  if args.bridge_diagnostics and args.policy != "qmap":
    raise ValueError("--bridge_diagnostics is valid only for policy=qmap.")
  replay_config = apply_replay_finals_config(args)
  stats = replay(args, finals_replay_config=replay_config)
  print_stats(args.policy, stats)
  if args.json_output:
    output_dir = os.path.dirname(os.path.abspath(args.json_output))
    if output_dir:
      os.makedirs(output_dir, exist_ok=True)
    metrics = stats.to_dict(args.policy, args.trace_path, args.dram_capacity)
    metrics["candidate_count"] = (
        8 if is_learned_policy(args.policy) else args.candidate_count)
    metrics["candidate_scope"] = (
        "full_dram" if args.policy in ("lru", "random", "lfu", "clock")
        else ("native_lru_tail_8" if is_learned_policy(args.policy)
              else "capd_selector_B_to_K"))
    metrics["rank_guard"] = args.rank_guard
    metrics["rank_score_penalty"] = args.rank_score_penalty
    metrics["replay_seed"] = args.random_seed
    metrics["command"] = " ".join(
        shlex.quote(value) for value in sys.argv)
    if replay_config is not None:
      metrics["schema_version"] = replay_config["schema_version"]
      metrics["workload"] = replay_config["run"]["workload"]
      metrics["workload_id"] = replay_config["run"]["workload"]
      metrics["experiment_contract"] = finals_config.contract_from_config(
          replay_config)
      metrics["config_fingerprint"] = finals_config.config_fingerprint(
          replay_config)
      metrics["git_commit"] = replay_config.get("run", {}).get(
          "git_commit", "unknown")
      metrics["evaluation_split"] = args.evaluation_split
      metrics["evaluation_trace_fingerprint"] = (
          finals_config.fingerprint_file(args.trace_path))
      metrics["test_trace_opened"] = args.evaluation_split == "test"
      metrics["test_used_for_selection"] = False
      if args.evaluation_split == "test":
        metrics["test_trace_fingerprint"] = metrics[
            "evaluation_trace_fingerprint"]
      metrics["nvm_capacity_pages"] = replay_config["memory"][
          "nvm_capacity_pages"]
      metrics["dram_initial_state"] = replay_config.get(
          "replay", {}).get("dram_initial_state")
      metrics["initial_residency"] = replay_config.get(
          "replay", {}).get("initial_residency")
      metrics["trace_page_backing"] = replay_config.get(
          "replay", {}).get("trace_page_backing")
      metrics["first_touch_accounting"] = replay_config.get(
          "replay", {}).get("first_touch_accounting")
      metrics["dirty_demotion_nvm_write"] = replay_config.get(
          "replay", {}).get("dirty_demotion_nvm_write")
      if replay_config["schema_version"] == finals_config.SCHEMA_VERSION:
        metrics.update(finals_config.artifact_identity_from_config(
            replay_config))
      if replay_config.get("stage5_variant") is not None:
        metrics["stage5_variant"] = dict(replay_config["stage5_variant"])
      if replay_config.get("stage6_variant") is not None:
        metrics["stage6_variant"] = dict(replay_config["stage6_variant"])
      if replay_config.get("optimization_variant") is not None:
        metrics["optimization_variant"] = dict(
            replay_config["optimization_variant"])
      metrics["selector_params"] = args.selector_params
      if args.selector_params:
        replay_selector = finals_config.load_json(args.selector_params)
        metrics["selector_fingerprint"] = (
            finals_config.selector_fingerprint(replay_selector))
        metrics["decision_holdout_fingerprint"] = replay_selector.get(
            "decision_holdout_fingerprint")
        metrics["candidate_coverage_validation"] = {
            key: replay_selector[key] for key in (
                "PoolRecall@B", "SelectorRecall@K", "EndToEndRecall@K",
                "TieCoverage@K", "NRegret")
            if key in replay_selector
        }
        metrics["candidate_coverage_metric_source"] = (
            "valid_trace"
            if finals_config.uses_independent_validation(replay_config)
            else "train_trace_decision_holdout")
      finals_config.write_json(
          os.path.join(output_dir, "resolved_config.json"), replay_config)
    if args.checkpoint:
      metrics["checkpoint"] = os.path.abspath(args.checkpoint)
      metrics["checkpoint_fingerprint"] = finals_config.fingerprint_file(
          args.checkpoint)
    if is_learned_policy(args.policy):
      metrics["learned_model"] = args.learned_model
      metrics["learned_model_fingerprint"] = finals_config.fingerprint_file(
          args.learned_model)
    metrics["cost_model"] = {
        "dram_read_cost": args.dram_read_cost,
        "dram_write_cost": args.dram_write_cost,
        "nvm_read_cost": args.nvm_read_cost,
        "nvm_write_cost": args.nvm_write_cost,
        "migration_cost": args.migration_cost,
    }
    if replay_config is not None:
      validation_selector = (
          finals_config.load_json(args.selector_params)
          if args.selector_params else None)
      finals_config.validate_result_contract(
          replay_config, metrics,
          selector_params=validation_selector,
          selector_config=getattr(args, "_data_config", replay_config),
          checkpoint_fingerprint=(
              metrics.get("checkpoint_fingerprint") if args.checkpoint
              else None))
    with open(args.json_output, "w") as output_file:
      json.dump(
          metrics,
          output_file,
          indent=2,
          sort_keys=True)
      output_file.write("\n")


if __name__ == "__main__":
  main()
